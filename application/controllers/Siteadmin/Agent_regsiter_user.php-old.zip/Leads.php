<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	class Leads extends CI_Controller {
		public function __construct()
		{
			parent::__construct();
			$this->load->library('form_validation'); 
			$this->load->helper('url');
			$this->load->helper('access_helper'); 
			  $this->load->helper('headerdata_helper');
			$this->load->library('session'); 
			$this->load->model('AdminModel'); 
			$sessionLogin = $this->session->userdata('adminLogged');
			if(!($sessionLogin)) { redirect(base_url('site-admin'));   } 
		}
		public function index() {
			   $role = $this->session->userdata('role');
    if (!check_permission($role, 'index')) {
    redirect(base_url('admin/dashboard'));
}
			  $role = $this->session->userdata('role');
    if (!check_permission($role, 'contact')) {
    redirect(base_url('admin/dashboard'));
}
			$data['title'] = 'Leads';
			
			$filters = [];
			$like = [];
			$agent = '';
			
			if ($this->session->userdata('role') == 'Sale Person') {
				$statuses = ['Assigned', 'Contacted', 'Interested', 'Not Interested', 'Zunk'];
				$this->db->where_in('status', $statuses);
				$data['leads'] = $this->db->get('buyers')->result();
			} else {
				// Base filter
				$filters['id >'] = '1';
				
				// Role-based filter
				if ($this->session->userdata('role') == 'Agent') {
					$filters['userid'] = $this->session->userdata('id');
				}
				
				// Filters from POST
				if ($this->input->server('REQUEST_METHOD') === 'POST') {
					$post = $this->input->post();
					
					if (!empty($post['start_date']) && !empty($post['end_date'])) {
						$filters['DATE(rDate) >='] = $post['start_date'];
						$filters['DATE(rDate) <='] = $post['end_date'];
					}
					
					if (!empty($post['uName'])) {
						$like['uName'] = $post['uName'];
					}
					
					if (!empty($post['mobile'])) {
						$like['mobile'] = $post['mobile'];
					}
					
					if (!empty($post['status'])) {
						$filters['status'] = $post['status'];
					}
					
					if (!empty($post['leads_type'])) {
						$filters['leads_type'] = $post['leads_type'];
					}
					if(isset($post['agent']) && $post['agent'] != '') {
						$agent = $post['agent'];
						$filters['userid'] = $agent;
					}
				}
				
				$data['leads'] = $this->AdminModel->getFilteredLeads($filters, $like, 'buyers', '*', 'id', 'desc');
			}
			
			// Agent-specific logic
			if ($this->session->userdata('role') == 'Agent' || $agent != '') { 
				if($agent > 0) { $userid = $agent; }
				else { $userid = $this->session->userdata('id'); }
				$data['assignleads'] = $this->AdminModel->getAgentLead($userid);
				
				if (!empty($data['assignleads'])) {
					$data['leads'] = array_merge($data['leads'], $data['assignleads']);
					$data['leads'] = array_map("unserialize", array_unique(array_map("serialize", $data['leads'])));
				}
			}
			 
			$data['agents'] = $this->AdminModel->getDataByMultipleColumns(array('role' => 'Agent'), 'adminLogin', 'id,fullName');
			$data['mainContent'] = 'siteAdmin/leads';
			$this->load->view('includes/admin/template', $data);
		}
		
		
		
		public function meeting() {
			   $role = $this->session->userdata('role');
    if (!check_permission($role, ' meeting')) {
    redirect(base_url('admin/dashboard'));
}
			$data['meeting_tasks'] = $this->AdminModel->get_tasks_with_conditions('meeting'); 
			$data['mainContent'] = 'siteAdmin/meeting_tasks_view'; 
			$this->load->view('includes/admin/template', $data);
		}
		
		public function follow() {
			   $role = $this->session->userdata('role');
    if (!check_permission($role, 'follow')) {
    redirect(base_url('admin/dashboard'));
}
			$data['lead_tasks'] = $this->AdminModel->get_tasks_with_conditions('Followup'); 
			
			$data['mainContent'] = 'siteAdmin/follow_ups'; 
			$this->load->view('includes/admin/template', $data);
		}
		
		public function updateFollowUpStatus() {
			   $role = $this->session->userdata('role');
    if (!check_permission($role, 'updateFollowUpStatus')) {
    redirect(base_url('admin/dashboard'));
}
			
            $id = $this->input->post('followUpId');
	        $updateData = array(
			'status'=> $this->input->post('status')
			);
			$result = $this->AdminModel->updateTable($id,'id','leads_comment',$updateData);
		} 
        
        
		public function Addleads() {
			   $role = $this->session->userdata('role');
    if (!check_permission($role, 'Addleads')) {
    redirect(base_url('admin/dashboard'));
}
			$data['title'] = 'Add Leads'; 
			
			if ($this->input->post('save')) {
				$this->form_validation->set_rules('phone', 'Phone', 'trim|required');
					$this->form_validation->set_rules('propertyType_sub', 'propertyType_sub', 'trim|required');
				$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
				
				if ($this->form_validation->run() != FALSE) {
					$payment_methods = $this->input->post('Payment_Method');
					if (!is_array($payment_methods)) {
						$payment_methods = array();
					}
					
					$insertData = array(
					'userid' => $this->session->userdata('id'),
					'userType' => $this->input->post('buyer'),
					'uName' => $this->input->post('name'),
					'preferred_location' => $this->input->post('preferred_location'),
					'address' => $this->input->post('address'),
					'email' => $this->input->post('email'),
					'city' => $this->input->post('city'),
					'mobile' => $this->input->post('phone'),
					'budget' => $this->input->post('budget'),
					'propertyType_sub' => $this->input->post('propertyType_sub'),
					
					'propertyType' => $this->input->post('propertyType'),
                  
				
					'max_budget' => $this->input->post('max_budget'),
				// 	'residential' => $this->input->post('residential'),
				// 	'commercial' => $this->input->post('commercial'),
					'Project_Builder'=> $this->input->post('Project_Builder'),
					'Profession'=> $this->input->post('Profession'),
					'Payment_Method'=> implode(', ', $payment_methods),
					'description' => $this->input->post('description'),
					'requirement' => $this->input->post('requirement'),
					'leads_type' => $this->input->post('leads_type'),
					'status' => $this->input->post('status'),
					'source' => $this->input->post('source')
					);
				
					
					$result = $this->AdminModel->addDataInTable($insertData, 'buyers');
					if ($result == TRUE) {
						// Lead ka ID get karein
						$leadId = $this->db->insert_id();  
						$userId = $this->session->userdata('id');
						
						// **Har case me assigned_leads table me entry dalna**
						$assignData = array(
						'leadid' => $leadId,
						'userid' => $userId, // Current logged-in user
						'rdate' => date('Y-m-d'),  
						);
						$this->AdminModel->addDataInTable($assignData, 'assigned_leads');
						
						$this->session->set_flashdata('message1', 'Leads added successfully.');
						redirect(base_url('admin/leads/add'));
					} 
				}
			}
			
			$data['selected_payment_method'] = $this->input->post('Payment_Method') ?? array();
			$data['mainContent'] = 'siteAdmin/leadsAdd'; 
			$this->load->view('includes/admin/template', $data);
		}
		
		
		
		public function editLeads() {
			   $role = $this->session->userdata('role');
    if (!check_permission($role, 'editLeads')) {
    redirect(base_url('admin/dashboard'));
}
			$data['title'] = 'Edit Leads'; 
			$id = $this->uri->segment(4);
			$userId = $this->session->userdata('id');
			
			// Fetch the lead details
			$data['leads'] = $this->AdminModel->getDataFromTableByField($id, 'buyers', 'id');
			$data['assignedLead'] = $this->AdminModel->getDataByMultipleColumns(array('leadid' => $id, 'userid' => $userId), 'assigned_leads');
			// Ensure user has access
			$role = $this->session->userdata('role');
			check_agent_access($data['leads'], $data['assignedLead'], $role);
			
			$username = $this->session->userdata('fullName');
			
			if ($this->input->post('save')) {
				// Validation rules
				$this->form_validation->set_rules('phone', 'Phone', 'trim');
				// $this->form_validation->set_rules('propertyType_sub', 'propertyType_sub', 'trim|required');
				$this->form_validation->set_rules('email', 'Email', 'trim|max_length[40]');
				// $this->form_validation->set_rules('address', 'Address', 'trim');
				// Add other validation rules as needed
				$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
				
				if ($this->form_validation->run() != FALSE) {
					$updateData = array(
					//'address' => $this->input->post('address'),
				// 	'location' => $this->input->post('location'),
					//'city' => $this->input->post('city'),
					//'mobile' => $this->input->post('phone'),
					//'email' => $this->input->post('email'),
					'budget' => $this->input->post('budget'),
				
					'max_budget' => $this->input->post('budgetmax'),
					'preferred_location' => $this->input->post('preferred_location'),
					'Project_Builder' => $this->input->post('Project_Builder'),
					'propertyType_sub' => $this->input->post('propertyType_sub'),
					
					'propertyType' => $this->input->post('propertyType'),
                  
					// 'Payment_Method' => $this->input->post('Payment_Method'),
					'requirement' => $this->input->post('requirement'),
					'Profession' => $this->input->post('Profession'),
					'description' => $this->input->post('description'),
				// 	'residential' => $this->input->post('residential'),
				// 	'commercial' => $this->input->post('commercial'),
					'status' => $this->input->post('status'),
					'source' => $this->input->post('source'),
					'leads_type' => $this->input->post('leads_type')
					);
					
					$currentData = $data['leads'][0];
					$logContent = array();
					
					// Check for changes and prepare log content
					if ($currentData->requirement != $updateData['requirement']) {
						$logContent['requirement'] = [
						'old' => $currentData->requirement,
						'new' => $updateData['requirement']
						];
					}
					if ($currentData->status != $updateData['status']) {
						$logContent['status'] = [
						'old' => $currentData->status,
						'new' => $updateData['status']
						];
					}
					if ($currentData->location != $updateData['location']) {
						$logContent['location'] = [
						'old' => $currentData->location,
						'new' => $updateData['location']
						];
					}
					
					// Log changes if any
					if (!empty($logContent)) {
						$logData = array(
						'userId' => $this->session->userdata('id'),
						'username' => $username,
						'leadId' => $id,
						'ip' => $this->input->ip_address(),
						'content' => json_encode($logContent)
						);
						$this->AdminModel->addDataInTable($logData, 'logs');
					}
					
					// Update lead data
					$result = $this->AdminModel->updateTable($id, 'id', 'buyers', $updateData);
					$this->session->set_flashdata('message1', 'Leads updated successfully.');
					redirect(base_url('admin/leads/edit') . '/' . $id);
				}
			}
			
			if ($this->input->post('submit')) {
				$this->form_validation->set_rules('comment', 'Comment', 'trim|required|min_length[3]|max_length[250]');
				$this->form_validation->set_rules('choice', 'Choice', 'trim'); // Add validation for choice field
				$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
				
				if ($this->form_validation->run() != FALSE) {
					$choice = $this->input->post('choice');
					$insertData = array(
					'leadId' => $id,
					'comment' => $this->input->post('comment'),
					'nextdt' => $this->input->post('nextdt'),
					'choice' => $choice,
					'status' => 'Active'
					);
					
					// Insert comment
					$result = $this->AdminModel->addDataInTable($insertData, 'leads_comment');
					
					// Handle meetings
					if ($choice == 'Meeting') {
						$sDate = $this->input->post('nextdt');
						if ($sDate == '') { $sDate = date('Y-m-d'); }
						$sDate = date('Y-m-d', strtotime($sDate));
						$addData = array(
						'subjectId' => $id,
						'task' => $this->input->post('comment'),
						'task_detail' => $this->input->post('comment'),
						'start_date' => $sDate,
						'choice' => 'meeting',
						'status' => 'active'
						);
						
						$result = $this->AdminModel->addDataInTable($addData, 'leadTask');
					}
					
					$this->session->set_flashdata('message2', 'Leads comment added successfully.');
					redirect(base_url('admin/leads/edit') . '/' . $id);
				}
			}
			
			// Fetch data for view
			$data['leadscomment'] = $this->AdminModel->getDataFromTableByField($id, 'leads_comment', 'leadId');
			$data['logs'] = $this->AdminModel->getDataFromTableByField($id, 'logs', 'leadId','id','desc');
			
			$data['mainContent'] = 'siteAdmin/leadsEdit'; 
			$this->load->view('includes/admin/template', $data);
		}
		
		
		public function deleteLeads(){
			   $role = $this->session->userdata('role');
    if (!check_permission($role, 'deleteLeads')) {
    redirect(base_url('admin/dashboard'));
}
			$id = $this->uri->segment('4');
			$role = $this->session->userdata('role');
			$buyers = $this->AdminModel->getDataFromTableByField($id,'buyers','id');
			if($buyers && $role == 'Agent'){
				if($buyers[0]->userid != $this->session->userdata('id')) { redirect(base_url('admin/dashboard')); }
			}
			$data['leads'] = $this->AdminModel->deleteRow($id,'buyers','id');
			$data['comment'] = $this->AdminModel->deleteRow($id,'leadTask_comment','leadtaskId');
			$data['task'] = $this->AdminModel->deleteRow($id,'leadTask','id');
			redirect(base_url('admin/leads'));
		}
		public function deleteComment(){
			
			   $role = $this->session->userdata('role');
    if (!check_permission($role, 'deleteComment')) {
    redirect(base_url('admin/dashboard'));
}
			$id = $this->uri->segment('4');
			$lid = $this->uri->segment('5');
			$data['leadscomment'] = $this->AdminModel->deleteRow($id,'leads_comment','id');
			$data['leads'] = $this->AdminModel->deleteRow($id,'buyers','id');
			redirect(base_url('admin/leads/edit').'/'.$lid);
		}
		
		
		/*Deal function start*/
		
		public function addDeal() {
			   $role = $this->session->userdata('addDeal');
    if (!check_permission($role, 'contact')) {
    redirect(base_url('admin/dashboard'));
}
			$leadId = $this->uri->segment('4');
			if ($this->input->post('save')) {
				$this->form_validation->set_rules('phone', 'phone', 'trim');
				$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
				if ($this->form_validation->run() != FALSE) {
					$propertyId = $this->input->post('addProperty');
					$idWhere = array('id' => $propertyId, 'status' => 'active');
					$checkpropertyID = $this->AdminModel->getDataByMultipleColumns($idWhere, 'properties', 'id,status');
					
					if ($checkpropertyID) {
						$where = array('id' => $leadId);
						$current_deal = $this->AdminModel->getDataByMultipleColumns($where, 'buyers', 'deal');
						$currentPropertyId = $current_deal[0]->deal;
						
						// Convert the current deal to an array if it's a comma-separated string
						$current_deal_array = ($currentPropertyId != '') ? explode(',', $currentPropertyId) : [];
						
						// Check if property is already added
						if (in_array($propertyId, $current_deal_array)) {
							$this->session->set_flashdata('error', 'Error: Property is already added.');
							} else {
							$updated_deal = ($currentPropertyId != '') ? $currentPropertyId . ',' . $propertyId : $propertyId;
							$updateData = array(
							'deal'=> $updated_deal,
							);					
							$result = $this->AdminModel->updateTable($leadId, 'id', 'buyers', $updateData);
							$this->session->set_flashdata('message1', 'Property added successfully.');
							
							// Insert into leadDeal table
							$propertyData = $this->AdminModel->getDataByMultipleColumns($idWhere, 'properties', 'name');
							$dataToInsert = array(
							'name' => $propertyData[0]->name,
							'lead_id' => $leadId,
							'properties_id' => $propertyId,
							'status' => 'Interested',
							'date' => date('Y-m-d H:i:s'),
							);
							$this->AdminModel->insertLeadDeal($dataToInsert);
						}
						} else {
						$this->session->set_flashdata('error', 'Sorry! This property does not exist.');
					}
				}
			}
			
			$where1 = array('id' => $leadId);
			$allDeals = $this->AdminModel->getDataByMultipleColumns($where1, 'buyers', 'deal');
			if ($allDeals) {
				if ($allDeals[0]->deal != '') {
					$dealString = $allDeals[0]->deal;
					$dealArray = explode(',', $dealString);
					$whereLead = array('p.id'=>$dealArray, 'l.lead_id' => $leadId);
					// $data['propertyDeal'] = $this->AdminModel->getDataFromTableByWhereIn('id', $dealArray, 'properties', 'id,name,address,city,state');
					$data['propertyDeal'] = $this->AdminModel->getDealProperties($whereLead);
				}
			}
			$data['mainContent'] = 'siteAdmin/addDeal'; 
			$this->load->view('includes/admin/template', $data);
		}
		
		public function updateDealStatus() {
			   $role = $this->session->userdata('role');
    if (!check_permission($role, 'updateDealStatus')) {
    redirect(base_url('admin/dashboard'));
}
			
            $pid = $this->input->post('propertyId');
            $leadId = $this->input->post('leadId');
	        $updateData = array(
			'Status'=> $this->input->post('status')
			);
			$where = array('properties_id' => $pid, 'lead_id' => $leadId);
			$result = $this->AdminModel->updateLeadStatus($where,'leadDeal',$updateData);
		} 
		
	}	