<style>
.donate_organ .btn{padding: .375rem .75rem;}
     
    
</style>
<div class="container inner_page_content">
	<?php if($properties){
        foreach ($properties as $property) {
        	# code...
       
		?>
		<h2 class="heading_main text-center"><?php echo $property->name ;?></h2>
    <div class="row result_deatils_sections">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="well well-sm result_detail_comp">
                <div class="row">

                        
                    <div class="col-sm-12 col-md-8">
					<h3>Property Details</h3>
					<table>
					<tbody>
					<tr>
					<td>
					<table>
						<tbody>
						<tr>
						<td><b>Property ID</b>:</td>
						<td><?php echo $property->id;?></td>
						</tr>
						<tr><td colspan="3"><p class="hr"></p></td></tr>
						<tr>
						<td><b>Property For </b>:</td>
						<td><?php echo $property->property_for;?></td>
						</tr>
						<?php if($property->built!=0){?>
						<tr><td colspan="3"><p class="hr"></p></td></tr>
						
						<tr>
						<td><b>Built Up Area</b>: </td>
						
						<td>
						<span><?php echo $property->built;?> (Sq.ft)</span>
						</td>
						</tr>
						<?php }?>
						<?php if($property->land!=0){ ?>
						<tr><td colspan="3"><p class="hr"></p></td></tr>
						
						<tr>
						<td><b>Land / Plot Area</b>: </td>
						
						<td>

						<span><?php echo $property->land;?> (Sq.ft)</span>

						</td>
						</tr>
						<?php }?>
						<?php if($property->carpet!=0){ ?>
						<tr><td colspan="3"><p class="hr"></p></td></tr>
						
						<tr>
						<td><b>Carpet Area</b>: </td>
						
						<td>

						<span><?php echo $property->carpet;?></span>
						</td>
						</tr>
						<?php }?>
						<tr><td colspan="3"><p class="hr"></p></td></tr>
						</tbody></table>
					     </td>
						</tr>
					</tbody></table>
					</div>
                    <div class="col-sm-12 col-md-4 col-xs-12 result_image_main ">
                        
                    <div id="slider">  
                    <?php if(!empty($property->image_one)){?>
                    <div class="slides">  
                      <img src="<?php echo base_url();?>assets/properties/<?php echo $property->image_one; ?>" width="100%" />
                     </div>
                     <?php }?>
                     
                    <?php if(!empty($property->image_two)){?>
                    <div class="slides">  
                      <img src="<?php echo base_url();?>assets/properties/<?php echo $property->image_two; ?>" width="100%" />
                     </div>
                     <?php }?>
                      
                    <?php if(!empty($property->image_three)){?>
                    <div class="slides">  
                      <img src="<?php echo base_url();?>assets/properties/<?php echo $property->image_three; ?>" width="100%" />
                     </div>
                     <?php }?> 
                      
                    <?php if(!empty($property->image_four)){?>
                    <div class="slides">  
                      <img src="<?php echo base_url();?>assets/properties/<?php echo $property->image_four; ?>" width="100%" />
                     </div>
                     <?php }?>
                      
                      <?php if(!empty($property->image_one) || !empty($property->image_two) || !empty($property->image_three) || !empty($property->image_four)){ ?>
                      <div id="dot"><span class="dot"></span><span class="dot"></span><span class="dot"></span><span class="dot"></span></div>
                      <?php }?>
                     </div>
                         <?php if(empty($property->image_one) && empty($property->image_two) && empty($property->image_three) && empty($property->image_four)){ ?>
                        <img style="height: 200px;" src="<?php echo base_url();?>assets/images/no-image.jpg" alt="" class="img-rounded img-responsive" />
                        <?php } ?>
                       
                    </div>
                    <div class="col-sm-12 col-md-12 col-xs-12 result_image_main ">
                        <p><?php echo $property->description; ?></p>
                        </div>  
                        
                    <?php if(!empty($property->additional)){
                    $addition=explode('~~--~~',$property->additional); $custom_value=explode('~~--~~',$property->additional_value);?>

                    <div class="col-sm-12 col-md-12 col-xs-12">
					   <h3>Additional Details</h3>
					   <div class="row">
					   <?php foreach($addition as $key=>$addit) {?>
					   
					   <div class="col-md-4"><span><b><?php echo $addit;?>:</b> <?php echo $custom_value[$key];?></span> </div>    
					   
                        <?php }?>
                        </div>
                    </div>
                    <?php }?>
                    <div class="col-sm-12 col-md-12 col-xs-12">
                        <h3>Property Address</h3>
                        <div class="row">
                          <div class="col-md-12"><span><?php echo $property->address;?></span></div>  
                            </div>
                            
                        </div>
                        <!--div class="col-sm-12 col-md-12 col-xs-12">
                            <h3>Location Map</h3>
                            <?php $state=$property->state; $city=$property->city;
                               $address=$state.'+'.$city;
                              // echo $address;
                               $replace = array(" ");
                               $replace_with = array("+");
                               $slug = str_replace($replace,$replace_with,$address);
                            ?>
                            <a target="_blank" class="btn btn-sm btn-primary" href="https://www.google.co.in/maps/place/<?php echo $address;?>">map</a>
                        </div-->
                    <div class="col-sm-12 col-md-12">
					<h3>Property Seller Detail</h3>
					<table>
					<tbody>
					<tr>
					<td>
					<table>
						<tbody>
						<tr>
						<td><b>Contact Person</b>:</td>
						<td><?php echo $property->person;?></td>
						</tr>
						<tr><td colspan="3"><p class="hr"></p></td></tr>
						<tr>
						<td><b>Mobile </b>:</td>
						<td><?php echo $property->phone;?></td>
						</tr>
						<tr><td colspan="3"><p class="hr"></p></td></tr>
						
						<tr>
						<td><b>Contact Address</b>: </td>
						
						<td>
						<span><?php echo $property->person_address;?></span>
						</td>
						</tr>
					
						
						<tr><td colspan="3"><p class="hr"></p></td></tr>
						</tbody></table>
					     </td>
						</tr>
					</tbody></table>
					</div>                        
                </div>
            </div>
        </div>
    </div>
<?php } } else{?>
<h4> No Result found</h4>
<?php } ?>

			</div>
			<script>
			    var index = 0;
var slides = document.querySelectorAll(".slides");
var dot = document.querySelectorAll(".dot");

function changeSlide(){

  if(index<0){
    index = slides.length-1;
  }
  
  if(index>slides.length-1){
    index = 0;
  }
  
  for(let i=0;i<slides.length;i++){
    slides[i].style.display = "none";
    dot[i].classList.remove("active");
  }
  
  slides[index].style.display= "block";
  dot[index].classList.add("active");
  
  index++;
  
  setTimeout(changeSlide,2000);
  
}

changeSlide();
			</script>
